package ass2;

public class ass2 {

	public static void main(String[] args) {
		String name = "Peter Medison";
		int gross_salary = 20000;
		double state_taxes;
		double net_salary;
		double personal_tax;
		state_taxes = gross_salary*(28.4/100);
		state_taxes = Math.round(state_taxes);
		if((gross_salary-state_taxes-7000>0))
		{
			personal_tax = (gross_salary-state_taxes-7000)*10/100;
		}
		else
		{
			personal_tax = 0;
		}
		net_salary = gross_salary-state_taxes-personal_tax;
		System.out.println("The Employee: " + name + " with gross salary of : " + gross_salary + " will get net salary: " + net_salary);
		System.out.println("State taxes are: " + state_taxes);
		System.out.println("Personal tax is: " + personal_tax);    
	}

}
