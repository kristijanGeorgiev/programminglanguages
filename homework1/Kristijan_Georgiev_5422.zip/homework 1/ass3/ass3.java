package ass3;

public class ass3 {
     public static void main(String[] args)
     {
    	 String s = "Java Developer";
    	 int n;
    	 char f_char,l_char,m_char;
    	 f_char = s.charAt(0);
    	 l_char = s.charAt(s.length()-1);
    	 if(s.length()%2==0)
    	 {
    		 n=s.length()/2;
    		 m_char =s.charAt(n);
    	 }
    	 else
    	 {
    		 n=s.length()/2;
    		 m_char=s.charAt(n);
    	 }
    	 int sum = 0;
    	 sum=f_char+l_char+m_char;
    	 int max;
    	 if(f_char>l_char && f_char>m_char)
    	 {
    		 max=f_char;
    	 }
    	 else if(l_char>f_char && l_char>m_char)
    	 {
    		 max=l_char;
    	 }
    	 else
    	 {
    		 max=m_char;
    	 }
    	 System.out.println("My string is: " + s);
    	 System.out.println("Its first character is: " + f_char);
    	 System.out.println("Its last character is: " + l_char);
    	 System.out.println("Its middle character is: " + m_char);
    	 System.out.println("The sum of the characters is: " + sum);
    	 System.out.println("The biggest character of these three is: " + (char)max + " with code of: " + max);
     }
}
