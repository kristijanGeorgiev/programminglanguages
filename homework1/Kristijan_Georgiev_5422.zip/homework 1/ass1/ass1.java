package ass1;

public class ass1 {
     public static void main(String[] args)
     {
    	 double number = (double)(Math.random()*100);
    	 int num = (int) number;
    	 double num1 = number-num;
    	 char code = (char) num;
    	 System.out.println("From 0..100, the computer picked " + number );
    	 System.out.println("Integer part of this number is " + num);
    	 System.out.println("Decimal part of this number is " + num1);
    	 System.out.println("Character with code: " + num + " is: " + code);
     }
}
